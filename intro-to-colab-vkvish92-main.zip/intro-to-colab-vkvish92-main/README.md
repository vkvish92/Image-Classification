[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/_52VcvYC)
# Assignment: Intro to Colab and Numpy, TF, and Visualization

## Overview
In this assignment, you will learn how to use Google's Colaboratory (Colab) for running Python code in the cloud with GPU/TPU accelerators. You will also practice using Numpy, TensorFlow, and Matplotlib for data visualization.

### Objectives
1. Familiarize yourself with Colab's interface and features.
2. Explore Python libraries such as Numpy and Matplotlib for scientific computing and visualization.
3. Work through provided Colab notebooks and answer related questions.

---

## Part 0: Intro to Colab
We will be using Google's Colaboratory (Colab) for some assignments in this class. You do not need to install anything on your machine, as the code runs in the cloud. However, you could replicate the setup locally on Linux (or Windows WSL) with Python, Numpy, Matplotlib, PyTorch, etc.

- [The Python Tutorial — Python 3.11.4 documentation](https://docs.python.org/3/tutorial/)
- [Python Tutorial (w3schools.com)](https://www.w3schools.com/python/)

To get started, review the following:
- [Colab tutorial](https://colab.research.google.com/notebooks/intro.ipynb)
- [Google's getting started notebook: NumpyTFandVisualization.ipynb](https://colab.research.google.com/drive/1qv40N9ZgDk4ZES20p4mA0dVBMduSZKO3?copy=true)

---

## Part 1: Numpy, TF, and Visualization
For this section, you'll focus on:
- Using Matplotlib and Numpy in Google Colab.
- Visualizing datasets, tensors, and activations.

**Resources:**
- [NumPy Tutorial: Your First Steps Into Data Science in Python](https://realpython.com/numpy-tutorial/)
- [Matplotlib Tutorials](https://matplotlib.org/stable/tutorials/index.html)

### Instructions
1. Work through the Colab notebook:  
   [Assignment Notebook](https://colab.research.google.com/drive/1BmiE0IHM7x6YsK6iSjd2_HNxVLq4-R5B?copy=true)
2. Answer the **6 questions** (numbered and bolded) in the notebook.
3. Once completed, export your notebook as a PDF:
   - Go to **File > Print > Save as PDF**.
4. Submit the PDF in GitHub Classroom by uploading it to this repository.

---

## Submission
1. Complete the notebook and answer all questions.
2. Export the completed notebook as a PDF.
3. Commit and push the PDF to your assigned GitHub Classroom repository.
4. Provide a link to your repo.

---

## Notes
If you encounter any issues:
- Refer to the provided tutorials.
- Ask questions!
